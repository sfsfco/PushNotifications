<?php $__env->startSection('title'); ?>
Show <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Show <?php echo e($title); ?></h3>
                <div class="pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('admins.index')); ?>"> Back</a>
                </div>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
              <div class="box-body">
                <div class="form-group">
                  <label for="name">Name:</label>
                  <?php echo e($admin->name); ?>

                </div>
                <div class="form-group">
                  <label for="email">Email address</label>
                  <?php echo e($admin->email); ?>

                </div>
                
              </div>
              <!-- /.box-body -->

            
          </div>
          <!-- /.box -->

          
          
          <!-- Input addon -->

        </div>
        <!--/.col (left) -->
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>